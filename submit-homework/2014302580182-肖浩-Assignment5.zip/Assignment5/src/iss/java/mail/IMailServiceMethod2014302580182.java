package iss.java.mail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class IMailServiceMethod2014302580182 implements IMailService{
	/**
     * 接收邮件的props文件
     */
    private final transient Properties props = System.getProperties();
    /**
     * 邮件服务器登录验证
     */
    private transient MailAuthenticator authenticator;

    /**
     * 邮箱session
     */
    private transient Session session;

	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		props.put("mail.store.protocol", "pop3");
        props.put("mail.pop3.host", "pop3.163.com");
        // 验证
        authenticator = new MailAuthenticator("m13006300171@163.com", "password");
        // 创建session
        session = Session.getInstance(props,authenticator);
        
	}

	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO Auto-generated method stub
		// 创建mime类型邮件
        final MimeMessage message = new MimeMessage(session);
        // 设置发信人
        message.setFrom(new InternetAddress(authenticator.getUsername()));
        // 设置收件人
        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
        // 设置主题
        message.setSubject(subject);
        // 设置邮件内容
        message.setContent(content.toString(), "text/html;charset=utf-8");
        // 发送
        Transport.send(message);
		
	}

	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		Store store = session.getStore("pop3");
        store.connect("pop3.163.com","m13006300171@163.com","password");

        // 获得邮箱内的邮件夹Folder对象，以"只读"打开
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);
        Message[] messages = folder.getMessages(1,2);
        int mailCounts = messages.length;
        //判断是否收到邮件
        
        folder.close(false);
        store.close();
        return false;
	}

	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		// TODO Auto-generated method stub
		Store store = session.getStore();
        store.connect();

        // 获得邮箱内的邮件夹Folder对象，以"只读"打开
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);

        Message[] messages = folder.getMessages(1,2);

        int mailCounts = messages.length;
        for(int i = 0; i < mailCounts; i++) {

            String subject1 = messages[i].getSubject();
            String from = (messages[i].getFrom()[0]).toString();

            System.out.println("第 " + (i+1) + "封邮件的主题：" + subject1);
            System.out.println("第 " + (i+1) + "封邮件的发件人地址：" + from);

            System.out.println("是否打开该邮件(yes/no)?：");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            if("yes".equalsIgnoreCase(input)) {
                // 直接输出到控制台中
                messages[i].writeTo(System.out);
            }
        }
        folder.close(false);
        store.close();
		return null;
	}

}
